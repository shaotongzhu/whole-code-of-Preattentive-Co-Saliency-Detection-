
Before running 'cosal_demo.m', you need to download 
three additional files created by Xiaodi Hou:
AW.mat
im2Vector.m
vector2Im.m

The three required files are included in
http://www.klab.caltech.edu/~xhou/papers/nips08matlab.zip







